<?php	
	// random function ------------------------------
	function swd_rand($length = 10, $letters = true, $numbers = true, $case = 'i')
	{
	    $chars = array();
	    if ($numbers)
	    {
	        $chars = array_merge($chars, range(48, 57));
	    }
	    if ($letters OR !$numbers)
	    {
	        $chars = array_merge($chars, range(65, 90), range(97, 122));
	    }
	    for ($string = ''; strlen($string) < $length; $string .= chr($chars[array_rand($chars)]));  
	    switch ($case)
	    {
	        case 'i': default: return $string;
	        case 'u': return strtoupper($string);
	        case 'l': return strtolower($string);
	    }
	}
	
	
	// make Dir
	ob_start("ob_gzhandler"); // compress page	
	if (!isset($_GET["dir"])) 
	{	
		$makedir = swd_rand(11); 
		if (!file_exists('uploads/' . $makedir . '')) 
		{
			mkdir("uploads/" . $makedir . "", 0755, true);
		} else 
		{
			header('Location: '.$_SERVER['REQUEST_URI']);
		}
	} 
	else 
	{
		$makedir = $_GET["dir"];
	}
	
		
	$targetFolder = 'uploads/' . $makedir;			
	$tempFile = $_FILES['Filedata']['tmp_name'];
	$targetFile = rtrim($targetFolder,'/') . '/' . $_FILES['Filedata']['name'];		
	move_uploaded_file($tempFile,$targetFile);

	echo  "dir=" . $makedir . "&" . "filename=".  $_FILES['Filedata']['name'] . "&" . "title=" . $_POST['title'] . "&" . "desc=". $_POST['desc'] . "&" . "tags=". $_POST['tags'] . "&" . "status=". $_POST['status'] . "&" . "cat=". $_POST['cat'];
	
?>