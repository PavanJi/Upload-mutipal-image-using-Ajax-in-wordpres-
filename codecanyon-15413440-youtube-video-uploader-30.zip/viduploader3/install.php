<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>Install | Video Uploader 3.0 Script (PHP)</title>
	<meta name="description" content="Video Uploader 3.0 PHP Script lets you add YouTube functionality to your own website or web application.">
	<meta name="keywords" content="YouTube, upload, video, API, php, script">
	<!-- Mobile viewport -->	
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
	<link  href="css/uploadifive13.css" rel="stylesheet" type="text/css" >	
	<style type="text/css">
	.auto-style1c {
		vertical-align: middle;
	}
	</style>
	
		<script>
		function validateForm() 
		{
		    var app_name = document.forms["myForm"]["app_name"].value; if (app_name == null || app_name== "") {alert("Please enter app_name"); return false;}	    
		    var app_api = document.forms["myForm"]["app_api"].value; if (app_api == null || app_api == "") {alert("Please enter app_api"); return false;}	    
		    var client_id = document.forms["myForm"]["client_id"].value; if (client_id == null || client_id == "") {alert("Please enter client_id"); return false;}
		    var client_secret = document.forms["myForm"]["client_secret"].value; if (client_secret == null || client_secret == "") {alert("Please enter client_secret"); return false;}
		    var redirect_url = document.forms["myForm"]["redirect_url"].value; if (redirect_url == null || redirect_url== "") {alert("Please enter video redirect_url"); return false;}
		}
	</script>
	
			
</head>

<body id="home">
	
	<!-- CSS-->
		<!-- Google web fonts. You can get your own bundle at http://www.google.com/fonts. Don't forget to update the CSS accordingly!-->
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif|Ubuntu' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/normalize.css">	
		<link rel="stylesheet" href="css/basic-style.css">				
	<!-- end CSS-->	
		
	<section id="page-header" class="clearfix">    
	<div class="wrapper">
	<h1><a href="http://viduploader3.com/"><img class="auto-style1c" height="75" src="images/videouploader3_icon.png" width="75" /></a> Video Uploader 3.0 Script (PHP)</h1> 
		
	</div>
	</section>
 
	<div class="wrapper" id="main"> 
			
		<div class="grid_6">  
			<h2>Description</h2>
			Video Uploader 3.0 is a YouTube API-based PHP script that lets you add YouTube uploading functionality to your own website or web application. It allows your users to upload videos directly to your own YouTube Channel, without the need to sign in to YouTube or even have Google Account. The script uses the latest version (3.0) of YouTube Application Programming Interface (API) to upload videos and and set the video's metadata (title, description, tags, status, and category). 
			The script uses Google OAuth 2.0 endpoints to create web server application that use OAuth 2.0 authorization to access Google APIs. OAuth 2.0 allows you to share specific data with an application while keeping your Google Account usernames, passwords, and other information private. 
			<br><br>
			While videos are being uploaded, progress bar show the current video upload progress so your users don’t have to second guess how long uploading videos is going to take.
			You can set video file size limit and video types with ease to ensure your website is free from abuse.
			<br><br>
			To make this script work, you’ll need to create and authorize an app in Google Developer Console at <a href="https://console.developers.google.com" target="_blank">https://console.developers.google.com</a> (very easy, see instructions).You can integrate this script in any application with minimum effort and without the need to use MySQL unless you need to save user's logs and info. 
			
		
			
			<br><br>
							
			Contact us: <a href="mailto:viduploader3@gmail.com">viduploader3@gmail.com</a>	
			<br>			
			Web: <a href="http://viduploader3.com">viduploader3.com</a>	
		</div>  
				
		<div class="grid_6">  
			
		<h2>Install</h2>
		
		Before installation please read the <a href="documents/">Setup Guide</a> carefully. 
				
		<form name="myForm" action="upload_to_youtube/save_my_api_keys.php" onsubmit="return validateForm();"  method="POST">
			<br>	    
		    <input  class="sign-up-input" id="app_name" name="app_name" placeholder="Application Name" type="text" /><br>
		    <input class="sign-up-input" id="app_api" name="app_api" placeholder="Application API" type="text" /><br>
		    <input class="sign-up-input" id="client_id" name="client_id" placeholder="Client ID" type="text" /><br>
		    <input class="sign-up-input" id="client_secret" name="client_secret" placeholder="Client Secret" type="text" /><br>
		    <input class="sign-up-input" id="redirect_url" name="redirect_url" placeholder="Redirect URL" type="text" /><br>
		    
		    <input class="uploadifive-button" type="submit" name="submit" value=" Install Script ">	    
		</form>
					
		</div>     
</div>


</body>
</html>