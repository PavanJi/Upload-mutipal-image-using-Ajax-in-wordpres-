Copyright (c) 2016 Video Uploader 3.0 Script
Contact us: viduploader3@gmail.com	
Web: viduploader3.com

Please refer to documentation file (documents/index.html) before using this script.

