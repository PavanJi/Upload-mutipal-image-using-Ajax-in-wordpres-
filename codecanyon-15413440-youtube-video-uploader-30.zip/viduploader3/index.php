<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>Video Uploader 3.0 Script (PHP)</title>
	<meta name="description" content="Video Uploader 3.0 PHP Script lets you add YouTube functionality to your own website or web application.">
	<meta name="keywords" content="YouTube, upload, video, API, php, script">
	<!-- Mobile viewport -->	
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
	
	<!-- ////////////////part1: uploader script////////////// -->
	<?php include("uploader_head.php");?>
	
	<style type="text/css">
	.auto-style1c {
		vertical-align: middle;
	}
	</style>		
</head>

<body id="home">
	
	<!-- CSS-->
		<!-- Google web fonts. You can get your own bundle at http://www.google.com/fonts. Don't forget to update the CSS accordingly!-->
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif|Ubuntu' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/normalize.css">	
		<link rel="stylesheet" href="css/basic-style.css">				
	<!-- end CSS-->	
		
	<section id="page-header" class="clearfix">    
	<div class="wrapper">
	<h1><a href="http://viduploader3.com/"><img class="auto-style1c" height="75" src="images/videouploader3_icon.png" width="75" /></a> Video Uploader 3.0 Script (PHP)</h1> 
		
	</div>
	</section>
 
	<div class="wrapper" id="main"> 
			
		<div class="grid_6">  
			<h2>Description</h2>
			Video Uploader 3.0 is a YouTube API-based PHP script that lets you add YouTube uploading functionality to your own website or web application. It allows your users to upload videos directly to your own YouTube Channel, without the need to sign in to YouTube or even have Google Account. The script uses the latest version (3.0) of YouTube Application Programming Interface (API) to upload videos and and set the video's metadata (title, description, tags, status, and category). 
			The script uses Google OAuth 2.0 endpoints to create web server application that use OAuth 2.0 authorization to access Google APIs. OAuth 2.0 allows you to share specific data with an application while keeping your Google Account usernames, passwords, and other information private. 
			<br><br>
			While videos are being uploaded, progress bar show the current video upload progress so your users don’t have to second guess how long uploading videos is going to take.
			You can set video file size limit and video types with ease to ensure your website is free from abuse.
			<br><br>
			To make this script work, you’ll need to create and authorize an app in Google Developer Console at <a href="https://console.developers.google.com" target="_blank">https://console.developers.google.com</a> (very easy, see instructions).You can integrate this script in any application with minimum effort and without the need to use MySQL unless you need to save user's logs and info. 
			
			<h2>Documents</h2>
			<a href="documents/">Setup Guide</a>
			
			<br><br>
							
			Contact us: <a href="mailto:viduploader3@gmail.com">viduploader3@gmail.com</a>	
			<br>			
			Web: <a href="http://viduploader3.com">viduploader3.com</a>	
		</div>  
				
		<div class="grid_6">  
			
		<h2>Demo</h2>
				
		<!-- //////////////part2: uploader form//////////// -->
		<?php include("uploader_form.php");?>
				
		</div>     
</div>






<a title="Web Analytics" href="http://clicky.com/100932097"><img alt="Web Analytics" width="0" height="0" src="//static.getclicky.com/media/links/badge.gif" border="0" /></a>
<script src="//static.getclicky.com/js" type="text/javascript"></script>
<script type="text/javascript">try{ clicky.init(100932097); }catch(e){}</script>
<noscript><p><img alt="Clicky" width="1" height="1" src="//in.getclicky.com/100932097ns.gif" /></p></noscript>

</body>
</html>