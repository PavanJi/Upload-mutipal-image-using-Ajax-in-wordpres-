<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>YouTube Video Uploader 3.0 (PHP)</title>
	<meta name="description" content="YouTube Video Uploader 3.0 lets you add YouTube functionality to your own website or web application.">
	<meta name="keywords" content="YouTube, upload, video, API">
	
	<!-- Mobile viewport -->	
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
	<link rel="shortcut icon" href="images/favicon.ico"  type="image/x-icon">

	<!-- part1: uploader script -->
	<?php include("uploader_head.php");?>
	
<style type="text/css">	
		.video-container {
		position:relative;
		padding-bottom:56.25%;
		padding-top:30px;
		height:0;
		overflow:hidden;
	}
	
	.video-container iframe, .video-container object, .video-container embed {
		position:absolute;
		top:0;
		left:0;
		width:100%;
		height:100%;
	}
</style>
					
</head>

<body id="home">
	
		<!-- CSS-->
		<!-- Google web fonts. You can get your own bundle at http://www.google.com/fonts. Don't forget to update the CSS accordingly!-->
		<link href='http://fonts.googleapis.com/css?family=Droid+Serif|Ubuntu' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/normalize.css">	
		<link rel="stylesheet" href="css/basic-style.css">
				
	<!-- end CSS-->
	
		
	<section id="page-header" class="clearfix">    
	<div class="wrapper">
		<h1>YouTube Video Uploader 3.0 (PHP)</h1>
	</div>
	</section>

	<!-- main content area -->   
	<div class="wrapper" id="main"> 
			
		<div class="grid_2"> 
		</div>
		
		<div class="grid_8">  					
			<div class="video-container">
			<iframe src="https://www.youtube.com/embed/<?php echo $_GET['video_key']; ?>?rel=0&amp;controls=0" frameborder="0" allowfullscreen></iframe>
			</div>
			<h2>Title:  <?php echo $_GET['title'] ;?></h2>	
			<h3>Desc:  <?php echo $_GET['desc'] ;?></h3>	
			<h3>Tags:  <?php echo $_GET['tags'] ;?></h3>	
			<h3>YouTube:  <a href='<?php echo "http://www.youtube.com/watch?v=" . $_GET['video_key'] ;?>' target="_blank"><?php echo "http://www.youtube.com/watch?v=" . $_GET['video_key'] ;?></a></h3>					
			
			<form name="form1" method="post" action="upload_to_youtube/deleteyoutubeapi3.php">
				<input name="video_key"  type="hidden" id="video_key" value="<? echo $_GET['video_key'] ; ?>">							
				<input name="Submit1" type="submit" value="Delete video" />		
			</form>
	


			<br>
			
			<br>					
			Contact us: <a href="mailto:viduploader3@gmail.com">viduploader3@gmail.com</a>	
			<br>			
			Web: <a href="http://viduploader3.com">viduploader3.com</a>	
			
		</div>  
		
		<div class="grid_2"> 
		</div>
				
		
      
  </div>
  

</body>
</html>