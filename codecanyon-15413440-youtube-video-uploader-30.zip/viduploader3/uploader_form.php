<!-- /////////// start video uploader content ////////// -->

<script>
	function validateForm() 
	{
	    var title = document.forms["myForm"]["title"].value; if (title == null || title== "") {alert("Please enter video title"); throw "exit"; return false;}	    
	    var desc = document.forms["myForm"]["desc"].value; if (desc == null || desc == "") {alert("Please enter video description"); throw "exit"; return false;}	    
	    var tags = document.forms["myForm"]["tags"].value; if (tags == null || tags == "") {alert("Please enter video tags"); throw "exit"; return false;}
	    var agree = document.forms["myForm"]["agree"].checked; if (agree == null || agree == "") {alert("You must to agree to our Terms of Use before uploaing video"); throw "exit"; return false;}
	}
</script>
	
	<form name="myForm"  >			
			<input  placeholder="Title" class="sign-up-input" name="title" id="title" type="text" value="" required /><br>			
			<textarea  style="height: 67px; width: 170px" placeholder="Description" class="sign-up-input" name="desc" id="desc" rows="2"></textarea><br>			
			<input placeholder="Tag1, Tag2, Tag3" class="sign-up-input" name="tags" id="tags" type="text" value="" /><br>			
			<select style="width: 202px" class="sign-up-input" id="status" name="status" style="width: 148px">
				<option selected="selected" value="public">Public</option>
				<option value="unlisted">Unlisted</option>
				<option value="private">Private</option>			
			</select><br>
			
			<select style="width: 202px" class="sign-up-input" id="cat" name="cat" style="width: 148px">				
				<option selected="selected" value="1">Film & Animation</option>
				<option value="2">Autos &amp; Vehicles</option>				
				<option value="10">Music</option>	
				<option value="20">Gaming</option>
				<option value="22">People & Blogs</option>		
				<option value="27">Education</option>							
				<option value="17">Sports</option>
				<option value="18">Short Movies</option>
				<option value="19">Travel & Events</option>
				<option value="21">Videoblogging</option>
				<option value="23">Comedy</option>
				<option value="24">Entertainment</option>
				<option value="25">News & Politic</option>
				<option value="26">Howto & Style</option>
				<option value="28">Science & Technology</option>
				<option value="30">Movies</option>
				<option value="29">Nonprofits & Activism</option>
				<option value="30">Movies</option>
				<option value="31">Anime/Animation</option>
				<option value="32">Action/Adventure</option>
				<option value="33">Classics</option>				
				<option value="34">Comedy</option>
				<option value="35">Documentary</option>
				<option value="36">Drama</option>
				<option value="37">Family</option>
				<option value="39">Horror</option>
				<option value="40">Sci-Fi/Fantasy</option>
				<option value="40">Thriller</option>
				<option value="43">Shows</option>
				<option value="44">Trailers</option>			
				
			</select>
			<br>	
			<input type="checkbox" name="agree" value="check" id="agree" /> I have read and agree to the <a href="#" target="_blank">Terms of Use</a>
			<br><br>				
			<input  id="file_upload" name="file_upload" type="file">
			<a class="uploadifive-button" href="javascript:uploadFiles();">Upload</a>
			
			<br><br>
			<div id="queue"></div>	
									
		</form>	
					
		<script type="text/javascript">		
			$(function() 
			{
				$('#file_upload').uploadifive
				({
					'auto'             : false,
					'buttonText'       : 'Browse',
					'fileSizeLimit'    : '1024 MB' ,
					'multi'            : false,
					'queueSizeLimit'   : 1,
					'checkScript'      : 'check-exists.php',								
					'queueID'          : 'queue',
					'fileType' 	   : ['video/x-ms-wmv', 'video/mp4', 'video/x-msvideo', 'video/x-sgi-movie', 'video/x-flv', 'video/webm', 'video/3gpp'],
					
					'uploadScript'     : 'uploadifive.php',
					'onUploadComplete' : function(file, data) {window.location = 'upload_to_youtube/processing.php?' + data;}
				});
			});		
			 function uploadFiles()
				   {						  
				      validateForm()				    
				     
				      $('#file_upload').data('uploadifive').settings.formData =
				      {
				      'title'  : document.getElementById("title").value, 
				      'desc'   : document.getElementById("desc").value, 
				      'tags'   : document.getElementById("tags").value, 
				      'status' : document.getElementById("status").value, 
				      'cat'    : document.getElementById("cat").value
				      },
				     
				      $('#file_upload').uploadifive('upload');
				   }   
		</script>
		
<!-- /////////// end video uploader content ////////// -->	