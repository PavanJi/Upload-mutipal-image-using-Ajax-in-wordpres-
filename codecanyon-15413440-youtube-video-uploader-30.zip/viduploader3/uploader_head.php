<!-- /////////// statrt video uploader stuff ////////// -->	



<link  href="css/uploadifive13.css" rel="stylesheet" type="text/css" >		
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery.uploadifive.min.js" type="text/javascript"></script>	
	
<!-- /////////// end video uploader stuff ////////// -->
	