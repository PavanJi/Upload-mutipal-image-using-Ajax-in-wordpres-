<?php
			$dir=$_GET["dir"]; 
			$filename=$_GET["filename"]; 	
			$title=$_GET["title"]; 
			$desc=$_GET["desc"]; 	
			$tags=$_GET["tags"]; 
			$status=$_GET["status"];
			$cat=$_GET["cat"];
						
			// upload to YouTube
			$videoPath = "../uploads/" . $dir . "/" . $filename ;	 	 
			require_once('uploadyoutubeapi3.php'); 	
							
			// optional: remove the video and dir from your server after uploading							    			    			    		    
			unlink($videoPath);	
			rmdir("../uploads/" . $dir);			
?>
		
		
		<script type="text/javascript">
			// wait until the page is loaded
			document.addEventListener('DOMContentLoaded', function() 
			{
				// maake loading more consistent by stting time out
				setTimeout(function(){}, 3000);
				window.location = "../videopage.php?video_key=<?php echo $video_key; ?>&title=<?php echo $title; ?>&desc=<?php echo $desc; ?>&tags=<?php echo $tags; ?>&cat=<?php echo $cat; ?>";
			}, false);								
		</script>
				
		</div>  
				
	


		    
	
			
					    
	