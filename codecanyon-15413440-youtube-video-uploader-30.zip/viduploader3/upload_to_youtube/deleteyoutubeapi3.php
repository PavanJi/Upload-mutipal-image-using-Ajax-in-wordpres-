<?php

	$video_key = $_POST["video_key"] ;
	

	// get tokens and change file name
	require_once 'random.php' ;
	$new_name = swd_rand(11); 
	
	// Get the .txt token file name in the dir
	$txtfile = glob("*.txt");	
	foreach($txtfile as $txtfile)
	{		
		$key = file_get_contents($txtfile);
		$file_title = basename($txtfile, ".txt");
		$new_token_name = $new_name . ".txt" ;
		rename($txtfile, $new_token_name);										
	}	
		
	require_once 'google-api-php-client/src/Google/autoload.php'; 
	require_once 'google-api-php-client/src/Google/Client.php';
	require_once 'google-api-php-client/src/Google/Service/YouTube.php';
	
	$application_name = 'presentationtubeapiv3'; 
	$client_id = '899752055823-n542mg30kvmike4qvhsrktrp70a0fou0.apps.googleusercontent.com';         
	$client_secret = '-eauAul28V2Wgi_uWF-OG1a7';

$scope = array('https://www.googleapis.com/auth/youtube.upload', 'https://www.googleapis.com/auth/youtube', 'https://www.googleapis.com/auth/youtubepartner');     
 
try{
    // Client init
    $client = new Google_Client();
    $client->setApplicationName($application_name);
    $client->setClientId($client_id);
    $client->setAccessType('offline');
    $client->setAccessToken($key);
    $client->setScopes($scope);
    $client->setClientSecret($client_secret);
 
    if ($client->getAccessToken()) {
        
         // Check to see if our access token has expired. If so, get a new one and save it to file for future use using index2_1.php                 
        if($client->isAccessTokenExpired()) {
            $newToken = json_decode($client->getAccessToken());
            $client->refreshToken($newToken->refresh_token);     
                                    
             	// Update token txt file
		file_put_contents($new_token_name, $client->getAccessToken());
        }
 
        $youtube = new Google_Service_YouTube($client);
        
        
        //****  delete video ****
	$youtube->videos->delete($video_key);
	//echo "Video deleted" ; 
        

    } else{
        echo 'Problems creating the client';
    }
 
} 


catch(Google_Service_Exception $e) {
    print "Caught Google service Exception ".$e->getCode(). " message is ".$e->getMessage();
    print "Stack trace is ".$e->getTraceAsString();
}catch (Exception $e) {
    print "Caught Google service Exception ".$e->getCode(). " message is ".$e->getMessage();
    print "Stack trace is ".$e->getTraceAsString();
}
	

?>

<script type="text/javascript">
			// wait until the page is loaded
			document.addEventListener('DOMContentLoaded', function() 
			{
				// maake loading more consistent by stting time out
				setTimeout(function(){}, 3000);
				window.location = "../index.php";
			}, false);								
		</script>
		
		