<?php
 
require_once 'google-api-php-client/src/Google/autoload.php'; 
require_once 'google-api-php-client/src/Google/Client.php';
require_once 'google-api-php-client/src/Google/Service/YouTube.php';

session_start();

require_once 'my_api_keys.php' ;

$APPNAME= $my_app_name ; 
$OAUTH2_CLIENT_ID = $my_client_id ;         
$OAUTH2_CLIENT_SECRET = $my_client_secret ;
$REDIRECT = $redirect_url ;

       
$client = new Google_Client();
$client->setClientId($OAUTH2_CLIENT_ID);
$client->setClientSecret($OAUTH2_CLIENT_SECRET);
$client->setScopes('https://www.googleapis.com/auth/youtube');
$client->setRedirectUri($REDIRECT);
$client->setApplicationName($APPNAME);
$client->setAccessType('offline');
 
// Define an object that will be used to make all API requests.
$youtube = new Google_Service_YouTube($client);
 
if (isset($_GET['code'])) {
    if (strval($_SESSION['state']) !== strval($_GET['state'])) {
        die('The session state did not match.');
    }
 
    $client->authenticate($_GET['code']);
    $_SESSION['token'] = $client->getAccessToken();
 
}
 
if (isset($_SESSION['token'])) {
    $client->setAccessToken($_SESSION['token']);
    //echo '<code>' . $_SESSION['token'] . '</code>';
    // save from here
    echo "Please wait..." ;
    $ret = file_put_contents('access_token.txt', $_SESSION['token']);
    
   ?>
   
   <script>
   window.location = "../index.php"
   </script>
    
   <?php	
	
      
}
 
// Check to ensure that the access token was successfully acquired.
if ($client->getAccessToken()) 
{
    try {
        // Call the channels.list method to retrieve information about the
        // currently authenticated user's channel.
        $channelsResponse = $youtube->channels->listChannels('contentDetails', array(
            'mine' => 'true',
        ));
 
        $htmlBody = '';
        foreach ($channelsResponse['items'] as $channel) 
        {
            // Extract the unique playlist ID that identifies the list of videos
            // uploaded to the channel, and then call the playlistItems.list method
            // to retrieve that list.
            $uploadsListId = $channel['contentDetails']['relatedPlaylists']['uploads'];
 
            $playlistItemsResponse = $youtube->playlistItems->listPlaylistItems('snippet', array(
                'playlistId' => $uploadsListId,
                'maxResults' => 50
            ));
 
            //$htmlBody .= "<h3>Videos in list $uploadsListId</h3><ul>";
            
            foreach ($playlistItemsResponse['items'] as $playlistItem) 
            {
                //$htmlBody .= sprintf('<li>%s (%s)</li>', $playlistItem['snippet']['title'], $playlistItem['snippet']['resourceId']['videoId']);
            }
            //$htmlBody .= '</ul>';
              $htmlBody = ''; 
              header("Location: ../index.php");
		die();
        }
    } catch (Google_ServiceException $e) {
        $htmlBody .= sprintf('<p>A service error occurred: <code>%s</code></p>',
            htmlspecialchars($e->getMessage()));
    } catch (Google_Exception $e) {
        $htmlBody .= sprintf('<p>An client error occurred: <code>%s</code></p>',
            htmlspecialchars($e->getMessage()));
    }
 
    $_SESSION['token'] = $client->getAccessToken();
    
} else 
{
    $state = mt_rand();
    $client->setState($state);
    $_SESSION['state'] = $state;
 
    $authUrl = $client->createAuthUrl();
    
    	header("Location:" . $authUrl);
	die();
	
	//$htmlBody = <<<END <center><h2>Google Account: YouTube</h2><h3>Please <a href="$authUrl">Choose an Account</a> before proceeding<h3></center> END;
}
?>
 
<!doctype html>
<html>
<head>
    <title>YouTube API</title>
</head>
<body>

<script>
window.location = '../index.php'
</script>

</body>
</html>