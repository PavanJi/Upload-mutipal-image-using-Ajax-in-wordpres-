<?php
// random function ------------------------------
	function swd_rand($length = 10, $letters = true, $numbers = true, $case = 'i')
	{
	    $chars = array();
	    if ($numbers)
	    {
	        $chars = array_merge($chars, range(48, 57));
	    }
	    if ($letters OR !$numbers)
	    {
	        $chars = array_merge($chars, range(65, 90), range(97, 122));
	    }
	    for ($string = ''; strlen($string) < $length; $string .= chr($chars[array_rand($chars)]));  
	    switch ($case)
	    {
	        case 'i': default: return $string;
	        case 'u': return strtoupper($string);
	        case 'l': return strtolower($string);
	    }
	}

?>