<?php
	// save_my_api_keys.php
	
	$st_start="<?php" . "\r\n" ; 
	
	$app_name = "$" . "my_app_name=" . '"' . $_POST['app_name'] . '"' .";" . "\r\n" ;		
	$app_api = "$" ."my_client_api=" . '"' . $_POST['app_api'] . '"' . ";" . "\r\n" ;		
	$client_id = "$" ."my_client_id=" . '"' . $_POST['client_id'] . '"' . ";" . "\r\n" ;		
	$client_secret = "$" ."my_client_secret=" . '"' . $_POST['client_secret'] . '"' . ";" . "\r\n" ;		
	$redirect_url = "$" ."redirect_url=" . "'" . $_POST['redirect_url'] . "'" . ";" . "\r\n" ;	
		
	$st_end="?>";	
		
	$data = $st_start . $app_name . $app_api . $client_id . $client_secret . $redirect_url  . $st_end ;	
	echo "Please wait." ;
	$ret = file_put_contents('my_api_keys.php', $data);
?>
	   <script>
	   	window.location = 'index.php' 
	   </script>
	   